# AKWA-BLOGS

- Our goal with this project is to provide a platform that allows users to have their own channel or blog.
- Our system allow the users to post, edit, view articles, and explore other people blog channels and articles based on search tags. The user can subscribe for blog channels from the explore feature and can read articles from his feed or add them to read later list.
- To run the app localy run the command (nodemon server) inside the root directory and run the command (ng serve) in angular-app directory.
- The app will be running locally on port 4200.

